from tkinter import *
import sys, os, csv, time
#Um
P_Um=0.1
I_Um=0.005
D_Um=0.05

#Ub1
P_Ub1=0.1
I_Ub1=0.005
D_Ub1=0.05

#Ub2
P_Ub2=0.1
I_Ub2=0.005
D_Ub2=0.05

os.chdir('D:\Python_projekty')
f = open("PID.txt", "w")
f.write(str(P_Um)+"\n"+str(I_Um)+"\n"+str(D_Um)+"\n")
f.write(str(P_Ub1)+"\n"+str(I_Ub1)+"\n"+str(D_Ub1)+"\n")
f.write(str(P_Ub2)+"\n"+str(I_Ub2)+"\n"+str(D_Ub2)+"\n")
f.close()

os.startfile('"D:\Python_projekty\pkss_projekt.exe"')


time.sleep(2) #Do testow 2

#window
window= Tk()
window.title("PKSS")

# PKSS photo
photo= PhotoImage(file="PKSS.png")
labelPhoto=Label (window, image=photo, bg="black").grid(row=0, column=0, sticky=E)



with open('Wyniki.csv', mode='r') as csv_file:
    csv_reader = csv.reader(csv_file,delimiter=';')
    line_count = 0
    # T0;Tr;Tpco;Tpm;Tzco;Tzco_ref;Tzm;Fcob_i;rtb_Fcob;TrSP;Um;Ub1;Ub2
    T0=[]
    for row in csv_reader:
        if line_count == 0:
            print(f'Column names are {",".join(row)}')
            line_count += 1
        else:
            T0.append(float(row[0]))

            #?MPEC?
            #Tzco
            Tzco = Label(window, text=str(row[4])[0:4]+" [°C]", fg="black",bg="orange", font="none 12")
            Tzco.place(x=90,y=60)
            #Tzcoref
            Tzcoref = Label(window, text=str(row[5])[0:4]+" [°C]", fg="black",bg="orange", font="none 12")
            Tzcoref.place(x=160,y=60)
            #Fzm
            fzm = str("{0:.2f}".format(float(row[10][0:6]) * 80))
            Fzm = Label(window, text=str(fzm)+" [t/h]", fg="black",bg="green", font="none 12")
            Fzm.place(x=230,y=60)
            #Tzm
            Tzm = Label(window, text=str(row[6])[0:4]+" [°C]", fg="black",bg="orange", font="none 12")
            Tzm.place(x=310,y=60)
            #Tpm
            Tpm = Label(window, text=str(row[3])[0:4]+" [°C]", fg="black",bg="orange", font="none 12")
            Tpm.place(x=155,y=270)


            #Budynek 1
            #Tr
            Tr1 = Label(window, text=str(row[1])[0:4]+" [°C]", fg="black",bg="orange", font="none 12")
            Tr1.place(x=500,y=60)
            #TrSP
            TrSP1 = Label(window, text=str(row[9])[0:4]+" [°C]", fg="black",bg="orange", font="none 12")
            TrSP1.place(x=570,y=60)
            #Tpco
            Tpco1 = Label(window, text=str(row[2])[0:4]+" [°C]", fg="black",bg="orange", font="none 12")
            Tpco1.place(x=640,y=60)
            #Fco1
            fco1 = str("{0:.2f}".format(float(row[11][0:6]) * 40))
            Fco1 = Label(window, text=str(fzm)+" [t/h]", fg="black",bg="green", font="none 12")
            Fco1.place(x=710,y=60)


            #Budynek 2
            #Tr
            Tr1 = Label(window, text=str(row[1])[0:4]+" [°C]", fg="black",bg="orange", font="none 12")
            Tr1.place(x=500,y=435)
            #TrSP
            TrSP1 = Label(window, text=str(row[9])[0:4]+" [°C]", fg="black",bg="orange", font="none 12")
            TrSP1.place(x=570,y=435)
            #Tpco
            Tpco1 = Label(window, text=str(row[2])[0:4]+" [°C]", fg="black",bg="orange", font="none 12")
            Tpco1.place(x=640,y=435)
            #Fco1
            fco1 = str("{0:.2f}".format(float(row[11][0:6]) * 40))
            Fco1 = Label(window, text=str(fzm)+" [t/h]", fg="black",bg="green", font="none 12")
            Fco1.place(x=710,y=435)



            #Regulatory[%]
            #Um
            um=str("{0:.2f}".format(float(row[10][0:6])*100))
            Um = Label(window, text=um+" [%]", fg="black",bg="grey", font="none 12")
            Um.place(x=80, y=170)
            #Ub1
            um=str("{0:.2f}".format(float(row[11][0:6])*100))
            Um = Label(window, text=um+" [%]", fg="black",bg="grey", font="none 12")
            Um.place(x=300, y=170)
            #Ub2
            um=str("{0:.2f}".format(float(row[12][0:6])*100))
            Um = Label(window, text=um+" [%]", fg="black",bg="grey", font="none 12")
            Um.place(x=300, y=550)





            line_count += 1
            window.update()
            time.sleep(0.1)
    print(f'Processed {line_count} lines.')

window.mainloop()